/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Jonathan
 */
public class DetalleSalida extends Movimiento{
    
    private int idDetalleSalidaProducto;
    private String idSalidaProducto;
    private String idProducto;
    
  
    public int getIdDetalleSalidaProducto() {
        return idDetalleSalidaProducto;
    }

    public void setIdDetalleSalidaProducto(int idDetalleSalidaProducto) {
        this.idDetalleSalidaProducto = idDetalleSalidaProducto;
    }

    public String getIdSalidaProducto() {
        return idSalidaProducto;
    }

    public void setIdSalidaProducto(String idSalidaProducto) {
        this.idSalidaProducto = idSalidaProducto;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }
    
    
    
}
